import './App.css';
import Home from './components/home'
import Login from './components/login'
import Register from './components/register'
import Todo from './components/todo'
import Error from './components/error'
import React from 'react';
import {Routes, Route, Redirect} from 'react-router-dom'

function App() {
  return (
    <div className="App">
      
      <Routes>
        <Route path='/' element={<Home />}/>
        <Route exact path='/login' element={<Login />}/>
        <Route exact path='/register' element={<Register />}/>
        <Route exact path='/todo' element={<Todo />}/>
        <Route path='*' element={<Error/>} />
      </Routes>
    </div>
  );
}

export default App;
