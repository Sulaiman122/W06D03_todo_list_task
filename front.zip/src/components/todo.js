import { useNavigate } from "react-router";
import React, { useState, useEffect } from "react";
import axios from "axios";
import { useLocation } from "react-router";

const Todo = () => {
  const navigate = useNavigate();
  const location = useLocation();
  let [Todo, setTodo] = useState([]);

  const addTodo = (e) => {
    e.preventDefault();
    if (e.target.todo.value) {
      setTodo([
        ...Todo,
        e.target.todo.value,
      ]);
    
    axios
      .post("http://localhost:4500/add", {
        email: location.state.userEmail,
        todos: [
          ...Todo,e.target.todo.value
        ],
      })
  }};


  const getmytodos = async () => {
    let res = await axios.post("http://localhost:4500/todo",{
        email: location.state.userEmail
      })
    console.log(res.data);
    setTodo(res.data);
  };

  useEffect(() => {
    if(localStorage.getItem("userEmail")){
      getmytodos();
    }else{
      navigate("/");
    }
  }, []);

  const removeItem = async(i) => {
    let res = await axios.post("http://localhost:4500/delete",{
        email: location.state.userEmail,
        index: i
      })
    console.log(res.data);
    setTodo(res.data);
  };

  const goHome = () => {
    localStorage.removeItem("userEmail");
    navigate("/");
  };
  return (
    <div className="home">
      <form onSubmit={addTodo}>
        <input type="text" name="todo" />
        <button type="submit">Add</button>
      </form>
      <h2>My Todos:</h2>
      {Todo ? Todo.map((item,index) => {
        return (
          <div style={{ display: "flex" }}>
            <p>{item}</p>
            <button id="deleteBTN" onClick={() => removeItem(index)}>x</button>
          </div>
        );
      }):<p></p>}
      <button style={{width:'110px'}} onClick={goHome}>Sign out</button>
    </div>
  );
};

export default Todo;
