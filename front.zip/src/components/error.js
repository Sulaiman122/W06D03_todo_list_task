import React from 'react'

const error = () => {
    return (
        <div>
            <h1>where are you going buddy</h1>
        </div>
    )
}

export default error
