import React from "react";
import { useNavigate } from "react-router-dom";
const Home = () => {
  let navigate = useNavigate();
  const goLogin = () => {
    navigate("/login");
  };
  const goRegister = () => {
    navigate("/register");
  };

  return (
    <div className="home">
      <h1>Welcome to the best</h1>
      <h2>TODO App</h2>
      <h3>You need to be a member to use this app</h3>
      <div className="buttons">
        <button onClick={goLogin}>Login</button>
        <button onClick={goRegister}>Register</button>
      </div>
    </div>
  );
};

export default Home;
